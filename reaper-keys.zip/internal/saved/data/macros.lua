{
  ["1"] = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "ArmTracks"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "CopyTrack"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "Paste"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ZoomTrackSelection",
        "NextTrack"
      },
      sequence = {
        "track_operator",
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "PrevTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ZoomTrackSelection",
        "NextTrack"
      },
      sequence = {
        "track_operator",
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ClearAllEnvelope"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "CutItems",
        "AllTrackItems"
      },
      sequence = {
        "timeline_operator",
        "timeline_selector"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ArmTracks"
      },
      sequence = {
        "command"
      }
    }
  },
  d = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "CutTrack"
      },
      sequence = {
        "command"
      }
    }
  },
  e = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "CopyItems",
        "NextItemEnd"
      },
      sequence = {
        "timeline_operator",
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextItemEnd"
      },
      sequence = {
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "Paste"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ProjectStart"
      },
      sequence = {
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "CopyItems",
        "LastItemEnd"
      },
      sequence = {
        "timeline_operator",
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ProjectStart"
      },
      sequence = {
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "Play",
        "LastItemEnd"
      },
      sequence = {
        "timeline_operator",
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ZoomTimeSelection",
        "MarkerRegion"
      },
      sequence = {
        "timeline_operator",
        "timeline_selector"
      }
    }
  },
  g = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "ToggleMute"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ToggleMute"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ToggleMute"
      },
      sequence = {
        "command"
      }
    }
  },
  j = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "Undo"
      },
      sequence = {
        "command"
      }
    }
  },
  k = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    }
  },
  n = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "ProjectStart"
      },
      sequence = {
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "CutItems",
        "LastItemEnd"
      },
      sequence = {
        "timeline_operator",
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "Undo"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "CycleRippleEditMode"
      },
      sequence = {
        "command"
      }
    }
  },
  r = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "Next4Measures"
      },
      sequence = {
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "Next4Measures"
      },
      sequence = {
        "timeline_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "Next4Measures"
      },
      sequence = {
        "timeline_motion"
      }
    }
  },
  t = {
    {
      context = "main",
      mode = "normal",
      parts = {
        "RenderTrack"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "NextTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ToggleVisualTimelineMode"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "visual_timeline",
      parts = {
        "CutItems"
      },
      sequence = {
        "timeline_operator"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "PrevTrack"
      },
      sequence = {
        "track_motion"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ToggleVisualTimelineMode"
      },
      sequence = {
        "command"
      }
    },
    {
      context = "main",
      mode = "visual_timeline",
      parts = {
        "SelectItems"
      },
      sequence = {
        "timeline_operator"
      }
    },
    {
      context = "main",
      mode = "normal",
      parts = {
        "ItemNormalize"
      },
      sequence = {
        "command"
      }
    }
  }
}