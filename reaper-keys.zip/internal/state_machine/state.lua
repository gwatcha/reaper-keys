{
  context = "main",
  key_sequence = "",
  last_command = {
    context = "main",
    mode = "normal",
    parts = {
      "NoOp"
    },
    sequence = {
      "command"
    }
  },
  last_searched_track_name = "^$",
  last_track_name_search_direction_was_forward = true,
  macro_commands = {},
  macro_recording = false,
  macro_register = "+",
  mode = "normal",
  timeline_selection_side = "left"
}