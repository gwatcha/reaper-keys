return {
  regex_match_entry_types = {
    number = '[1-9][0-9]*',
    register_location = '[0-9a-zA-Z]',
  },
}
